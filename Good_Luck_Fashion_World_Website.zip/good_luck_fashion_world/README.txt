GOOD LUCK FASHION WORLD — WEBSITE
==================================

Files:
- index.html = complete responsive website
- assets/ = your supplied logo and product photos

How to use:
1. Open index.html in a browser to preview it.
2. Upload the entire folder to a web host (for example, Netlify, GitHub Pages, or your hosting provider).
3. The WhatsApp number and store address are already included.

Note:
- Product prices/sizes were not supplied, so the website uses WhatsApp inquiry buttons instead of inventing prices.
